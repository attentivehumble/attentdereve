let currentInput = '';
let operation = '';
let firstOperand = null;

function appendNumber(number) {
    currentInput += number;
    document.getElementById('display').value = currentInput;
}

function setOperation(op) {
    if (currentInput === '') return;
    if (firstOperand === null) {
        firstOperand = parseFloat(currentInput);
    } else {
        calculateResult();
    }
    operation = op;
    currentInput = '';
}

function calculateResult() {
    if (firstOperand === null || currentInput === '') return;
    let secondOperand = parseFloat(currentInput);
    let result;

    switch (operation) {
        case '+':
            result = firstOperand + secondOperand;
            break;
        case '-':
            result = firstOperand - secondOperand;
            break;
        case '*':
            result = firstOperand * secondOperand;
            break;
        case '/':
            result = firstOperand / secondOperand;
            break;
        default:
            return;
    }
    document.getElementById('display').value = result;
    currentInput = '';
    firstOperand = null;
}

function clearDisplay() {
    document.getElementById('display').value = '';
    currentInput = '';
    firstOperand = null;
    operation = '';
}

function showSection(section) {
    document.getElementById('calculator').style.display = 'none';
    document.getElementById('about').style.display = 'none';
    document.getElementById('contact').style.display = 'none';
    
    document.getElementById(section).style.display = 'block';
}

// Показываем калькулятор по умолчанию
showSection('calculator');
